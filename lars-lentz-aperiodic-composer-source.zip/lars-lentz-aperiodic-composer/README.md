# Lars Lentz's Aperiodic Composer

v1.01

An installable, local-first PWA that generates Penrose-inspired quasi-periodic tilings and converts them into exportable musical event sequences (MIDI, CSV, JSON preset) for ambient/experimental composers.

Everything runs client-side in the browser — there's no backend, no database, and no account required. Presets are the only persistence, saved/loaded as JSON files you export/import yourself.

## Getting started

```bash
npm install
npm run dev
```

This starts a local Vite dev server (default `http://localhost:5173`).

## Building for production

```bash
npm run build
```

Output goes to `dist/`. Preview the production build locally with:

```bash
npm run serve
```

## Deploying to GitHub Pages

This repo includes a ready-to-use GitHub Actions workflow (`.github/workflows/deploy.yml`) that builds and publishes the site automatically. **You must point Pages at this workflow — pushing the repo alone is not enough.**

1. Push this repo to GitHub.
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, select **GitHub Actions** (not "Deploy from a branch" — that option just serves whatever files you pushed as-is, without building the app, which shows a blank white page).
4. Push to (or merge into) the `main` branch, or go to the **Actions** tab and manually run the "Deploy to GitHub Pages" workflow.
5. Watch the **Actions** tab until the workflow finishes with a green check. Your site is then live at `https://<your-username>.github.io/<repo-name>/`.

GitHub Pages project sites are served from a sub-path (`/<repo-name>/`), so the workflow automatically sets `BASE_PATH` to your repository's exact name (case-sensitive) at build time — you don't need to configure anything for the default case.

**If you deploy to a custom domain at the root** (via a `CNAME` file), or a user/organization Pages repo named `<username>.github.io` (which is served at the domain root, not a sub-path), edit `.github/workflows/deploy.yml` and change `BASE_PATH` in the build step to `/`.

**Building locally for a specific sub-path** (e.g. to test before pushing):

```bash
BASE_PATH=/<repo-name>/ npm run build
```

### Troubleshooting: blank/white screen after deploying

This almost always means the deployed page loaded `index.html` but couldn't load its JS/CSS assets — check your browser's console (right-click → Inspect → Console/Network tab) for 404 errors, then match against these causes:

- **Pages source isn't set to "GitHub Actions".** If it's set to "Deploy from a branch", GitHub is serving your raw, unbuilt source files (or a stale build), not the compiled app. Fix: Settings → Pages → Source → GitHub Actions, then re-run the workflow from the Actions tab.
- **The workflow hasn't run yet, or failed.** Check the **Actions** tab for a red ✗. Click into the failed run to see the error (commonly a dependency install issue — re-run after fixing `package.json` if needed).
- **Wrong base path.** If the console shows 404s for `/assets/...` or the icons/manifest, the built `BASE_PATH` doesn't match your actual repo name (e.g. you renamed the repo after the first deploy, or you're using a custom domain but still building with the `/repo-name/` sub-path). Fix by adjusting `BASE_PATH` in `.github/workflows/deploy.yml` to match, then push again.
- **Stale service worker cache.** If you fixed the above but still see a white screen, the installable PWA's service worker may have cached the old broken shell. Hard-refresh (Ctrl/Cmd+Shift+R), or open DevTools → Application → Service Workers → Unregister, then reload.

Note: GitHub Pages only serves static files as-is — it does not run a build step for you unless you use the included Actions workflow. Don't upload the raw source (this repo) directly as the Pages branch content; either let the included Actions workflow build it, or run `npm run build` yourself and publish the resulting `dist/` folder.

## Stack

- Vite + React + TypeScript
- Tailwind CSS + shadcn/ui components
- `vite-plugin-pwa` for the installable offline PWA shell
- Native Web Audio API for playback (no audio samples, oscillator-based synth)
- Hand-encoded raw Standard MIDI File bytes for MIDI export (no external MIDI library)

## Where things live

- `src/lib/penrose.ts` — Penrose (P2 kite/dart triangle) tiling generator via recursive deflation
- `src/lib/traversal.ts` — tile ordering strategies (radial, spiral, row-scan, angle-sweep, adjacency-walk, depth-order)
- `src/lib/scales.ts` — musical scale definitions and degree-to-MIDI-note mapping
- `src/lib/musicMapping.ts` — converts a tiling + generator params into a music event sequence, including the "Melodic / Interweave" mode's per-voice smoothed melodic contour
- `src/lib/audioEngine.ts` — Web Audio playback engine (oscillator synth, per-event pan/envelope, per-voice mute/volume mixing)
- `src/lib/midiExport.ts`, `csvExport.ts`, `presetExport.ts` — file export/import
- `src/components/ControlPanel.tsx` — all generation/melody/mixing controls
- `src/pages/Home.tsx` — main app shell, transport, and voice mixer

## License

All rights reserved by the author unless you add your own license file.
