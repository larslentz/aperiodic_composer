# Lars Lentz's Aperiodic Composer

v1.01

An installable, local-first PWA that generates Penrose-inspired quasi-periodic tilings and converts them into exportable musical event sequences (MIDI, CSV, JSON preset) for ambient/experimental composers.

Everything runs client-side in the browser — there's no backend, no database, and no account required. Presets are the only persistence, saved/loaded as JSON files you export/import yourself.

## Getting started

```bash
npm install
npm run dev
```

This starts a local Vite dev server (default `http://localhost:5173`).

## Building for production

```bash
npm run build
```

Output goes to `dist/`. Preview the production build locally with:

```bash
npm run serve
```

## Deploying to GitHub Pages

GitHub Pages project sites are served from a sub-path (`https://<user>.github.io/<repo>/`), so set `BASE_PATH` to that sub-path before building:

```bash
BASE_PATH=/<repo-name>/ npm run build
```

Then publish the contents of `dist/` to your `gh-pages` branch (or via GitHub Actions) however you prefer — this is a fully static site, so any static host works (GitHub Pages, Netlify, Vercel, S3, etc.).

## Stack

- Vite + React + TypeScript
- Tailwind CSS + shadcn/ui components
- `vite-plugin-pwa` for the installable offline PWA shell
- Native Web Audio API for playback (no audio samples, oscillator-based synth)
- Hand-encoded raw Standard MIDI File bytes for MIDI export (no external MIDI library)

## Where things live

- `src/lib/penrose.ts` — Penrose (P2 kite/dart triangle) tiling generator via recursive deflation
- `src/lib/traversal.ts` — tile ordering strategies (radial, spiral, row-scan, angle-sweep, adjacency-walk, depth-order)
- `src/lib/scales.ts` — musical scale definitions and degree-to-MIDI-note mapping
- `src/lib/musicMapping.ts` — converts a tiling + generator params into a music event sequence, including the "Melodic / Interweave" mode's per-voice smoothed melodic contour
- `src/lib/audioEngine.ts` — Web Audio playback engine (oscillator synth, per-event pan/envelope, per-voice mute/volume mixing)
- `src/lib/midiExport.ts`, `csvExport.ts`, `presetExport.ts` — file export/import
- `src/components/ControlPanel.tsx` — all generation/melody/mixing controls
- `src/pages/Home.tsx` — main app shell, transport, and voice mixer

## License

All rights reserved by the author unless you add your own license file.
