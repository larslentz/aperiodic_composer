# Lars Lentz's Aperiodic Composer

v1.01

An installable, local-first PWA that generates Penrose-inspired quasi-periodic tilings and converts them into exportable musical event sequences (MIDI, CSV, JSON preset) for ambient/experimental composers.

Everything runs client-side in the browser — there's no backend, no database, and no account required. Presets are the only persistence, saved/loaded as JSON files you export/import yourself.

## Getting started

```bash
npm install
npm run dev
```

This starts a local Vite dev server (default `http://localhost:5173`).

## Building for production

```bash
npm run build
```

Output goes to `dist/`. Preview the production build locally with:

```bash
npm run serve
```

## Deploying to GitHub Pages

This repo includes a ready-to-use GitHub Actions workflow (`.github/workflows/deploy.yml`) that builds and publishes the site automatically.

1. Push this repo to GitHub.
2. In the repo, go to **Settings → Pages**, and under **Build and deployment → Source**, choose **GitHub Actions**.
3. Push to (or merge into) the `main` branch. The workflow builds the app and deploys it — no manual build/upload step needed.
4. Your site will be live at `https://<your-username>.github.io/<repo-name>/`.

GitHub Pages project sites are served from a sub-path (`/<repo-name>/`), so the workflow automatically sets `BASE_PATH` to your repository name at build time — you don't need to configure anything for the default case.

**If you deploy to a custom domain at the root** (via a `CNAME` file), or your setup otherwise needs the app served from `/` instead of `/<repo-name>/`, edit `.github/workflows/deploy.yml` and change the `BASE_PATH` value in the build step to `/`.

**Building locally for a specific sub-path** (e.g. to test before pushing):

```bash
BASE_PATH=/<repo-name>/ npm run build
```

Note: GitHub Pages only serves static files as-is — it does not run a build step for you. Don't upload the raw source (this repo) directly as the Pages site content; either let the included Actions workflow build it, or run `npm run build` yourself and publish the resulting `dist/` folder.

## Stack

- Vite + React + TypeScript
- Tailwind CSS + shadcn/ui components
- `vite-plugin-pwa` for the installable offline PWA shell
- Native Web Audio API for playback (no audio samples, oscillator-based synth)
- Hand-encoded raw Standard MIDI File bytes for MIDI export (no external MIDI library)

## Where things live

- `src/lib/penrose.ts` — Penrose (P2 kite/dart triangle) tiling generator via recursive deflation
- `src/lib/traversal.ts` — tile ordering strategies (radial, spiral, row-scan, angle-sweep, adjacency-walk, depth-order)
- `src/lib/scales.ts` — musical scale definitions and degree-to-MIDI-note mapping
- `src/lib/musicMapping.ts` — converts a tiling + generator params into a music event sequence, including the "Melodic / Interweave" mode's per-voice smoothed melodic contour
- `src/lib/audioEngine.ts` — Web Audio playback engine (oscillator synth, per-event pan/envelope, per-voice mute/volume mixing)
- `src/lib/midiExport.ts`, `csvExport.ts`, `presetExport.ts` — file export/import
- `src/components/ControlPanel.tsx` — all generation/melody/mixing controls
- `src/pages/Home.tsx` — main app shell, transport, and voice mixer

## License

All rights reserved by the author unless you add your own license file.
