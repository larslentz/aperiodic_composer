import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import { VitePWA } from "vite-plugin-pwa";

// GitHub Pages project sites are served from a sub-path:
// https://<user>.github.io/<repo>/
// The bundled GitHub Actions workflow (.github/workflows/deploy.yml) sets
// BASE_PATH automatically from the repository name when it builds, so a
// plain `git push` just works. Override it yourself for local builds
// targeting a different sub-path, or leave it unset to build for "/".
const basePath = process.env.BASE_PATH || "/";
const port = Number(process.env.PORT) || 5173;

export default defineConfig({
  base: basePath,
  plugins: [
    react(),
    tailwindcss(),
    VitePWA({
      registerType: "autoUpdate",
      base: basePath,
      includeAssets: ["icon-512.png"],
      manifest: {
        id: basePath,
        name: "Lars Lentz's Aperiodic Composer",
        short_name: "Aperiodic Composer",
        description:
          "Generate Penrose-inspired quasi-periodic tilings and convert them into exportable musical sequences.",
        start_url: basePath,
        scope: basePath,
        display: "standalone",
        background_color: "#0a0a0c",
        theme_color: "#0a0a0c",
        icons: [
          {
            src: "icon-512.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "any",
          },
          {
            src: "icon-512.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "maskable",
          },
        ],
      },
      workbox: {
        globPatterns: ["**/*.{js,css,html,png,svg,ico,woff2}"],
        navigateFallback: `${basePath}index.html`,
        runtimeCaching: [
          {
            urlPattern: ({ request }) =>
              request.destination === "document" ||
              request.destination === "script" ||
              request.destination === "style",
            handler: "StaleWhileRevalidate",
            options: { cacheName: "penrose-shell" },
          },
        ],
      },
      devOptions: {
        enabled: false,
      },
    }),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
    },
    dedupe: ["react", "react-dom"],
  },
  build: {
    outDir: path.resolve(import.meta.dirname, "dist"),
    emptyOutDir: true,
  },
  server: {
    port,
    host: "0.0.0.0",
  },
  preview: {
    port,
    host: "0.0.0.0",
  },
});
