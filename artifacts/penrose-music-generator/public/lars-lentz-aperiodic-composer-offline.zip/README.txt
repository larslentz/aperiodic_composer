Lars Lentz's Aperiodic Composer (offline build) — v1.01
=========================================================

This is a static, self-contained build of the app. It runs entirely
in your browser (no server, no account, no internet connection needed
once loaded) and never sends your data anywhere.

HOW TO RUN IT
-------------
Because this is a set of ES module files, most browsers will block it
if you just double-click index.html (the file:// origin blocks module
loading). Instead, serve this folder with any simple local static
server, for example:

  npx serve .

or, if you have Python installed:

  python3 -m http.server 8080

Then open the printed local URL (e.g. http://localhost:3000 or
http://localhost:8080) in your browser.

Once loaded, you can also "Install" it as an app from your browser's
address bar / menu for a native-feeling offline experience.

WHAT'S INSIDE
-------------
This is the production build output (HTML/CSS/JS + a service worker
for offline caching). It's the same app you see running online, frozen
as a static snapshot.
